import logging
from telegram import Update,InlineKeyboardButton,InlineKeyboardMarkup
from telegram.ext import Application,CommandHandler,CallbackQueryHandler,ContextTypes
from bot.config import settings
from bot.db import *
logging.basicConfig(format='%(asctime)s %(levelname)s %(name)s: %(message)s',level=logging.INFO)
def admin(uid): return uid in settings.admin_ids
async def member(ctx,uid):
    try: return (await ctx.bot.get_chat_member(settings.channel_username,uid)).status in {'creator','administrator','member'}
    except Exception: return False
async def start(u,c):
    x=u.effective_user
    if not await member(c,x.id):
        kb=[[InlineKeyboardButton('📢 عضویت در کانال',url=f"https://t.me/{settings.channel_username.lstrip('@')}")],[InlineKeyboardButton('✅ بررسی عضویت',callback_data='check_member')]]
        await u.message.reply_text('برای ثبت‌نام ابتدا عضو کانال شوید.',reply_markup=InlineKeyboardMarkup(kb)); return
    m=register_member(x.id,x.username,x.first_name); await u.message.reply_text(f"✅ ثبت‌نام انجام شد.\n\n🎫 شماره شرکت: {m['participant_number']}")
async def check(u,c):
    q=u.callback_query; await q.answer(); x=q.from_user
    if await member(c,x.id):
        m=register_member(x.id,x.username,x.first_name); await q.edit_message_text(f"✅ عضویت تأیید شد.\n\n🎫 شماره شرکت: {m['participant_number']}")
    else: await q.edit_message_text('❌ عضویت شما هنوز تأیید نشده است.')
async def mynumber(u,c):
    m=get_user(u.effective_user.id); await u.message.reply_text(f"🎫 شماره شرکت شما: {m['participant_number']}" if m else '❌ ابتدا /start را اجرا کنید.')
async def vote(u,c):
    if get_phase()!='voting': await u.message.reply_text('⏳ رأی‌گیری فعال نیست.'); return
    x=u.effective_user
    if not await member(c,x.id): await u.message.reply_text('❌ برای رأی دادن باید عضو کانال باشید.'); return
    m=register_member(x.id,x.username,x.first_name); kb=[[InlineKeyboardButton(z['name'],callback_data=f"vote:{z['id']}")] for z in candidates()]
    if not kb: await u.message.reply_text('❌ هنوز نامزدی ثبت نشده است.'); return
    await u.message.reply_text(f"🎫 شماره شرکت: {m['participant_number']}\n\n🗳️ نامزد را انتخاب کنید:",reply_markup=InlineKeyboardMarkup(kb))
async def vote_cb(u,c):
    q=u.callback_query; await q.answer()
    try: cid=int(q.data.split(':',1)[1])
    except: await q.edit_message_text('❌ درخواست نامعتبر.'); return
    await q.edit_message_text(cast_vote(q.from_user.id,cid)[1])
async def addc(u,c):
    if not admin(u.effective_user.id): return
    name=' '.join(c.args).strip()
    if not name: await u.message.reply_text('مثال: /addcandidate علی رضایی'); return
    add_candidate(name); log_admin(u.effective_user.id,'add_candidate',name); await u.message.reply_text(f'✅ نامزد «{name}» اضافه شد.')
async def startv(u,c):
    if admin(u.effective_user.id): set_phase('voting'); log_admin(u.effective_user.id,'start_vote'); await u.message.reply_text('🗳️ رأی‌گیری شروع شد.')
async def endv(u,c):
    if admin(u.effective_user.id): set_phase('ended'); log_admin(u.effective_user.id,'end_vote'); await u.message.reply_text('🛑 رأی‌گیری پایان یافت و رأی‌ها قفل شدند.')
async def results(u,c):
    if not admin(u.effective_user.id): return
    rows=results_db(); await u.message.reply_text('📊 نتایج وجود ندارد.') if not rows else await u.message.reply_text('📊 نتایج رأی‌گیری:\n\n'+'\n'.join(f"👤 {r['name']} — 🗳️ {r['vote_count']} رأی" for r in rows))
async def draw(u,c):
    if not admin(u.effective_user.id): return
    w,msg=draw_winner()
    if not w: await u.message.reply_text(msg); return
    log_admin(u.effective_user.id,'draw',w.get('draw_id','')); await u.message.reply_text(f"{msg}\n\n🎫 شماره برنده: {w['winner_number']}\n👤 نام: {w['name']}\n🔐 شناسه: {w['draw_id']}")
async def stat(u,c):
    s=status(); await u.message.reply_text(f"📊 وضعیت\n\nمرحله: {s['phase']}\n👥 شرکت‌کنندگان: {s['members']}\n👤 نامزدها: {s['candidates']}\n🗳️ رأی‌ها: {s['votes']}")
async def adm(u,c):
    if admin(u.effective_user.id): await u.message.reply_text('/addcandidate نام\n/startvote\n/endvote\n/results\n/draw\n/status\n/lastdraw')
async def last(u,c):
    if not admin(u.effective_user.id): return
    r=last_draw(); await u.message.reply_text('ℹ️ هنوز قرعه‌کشی ثبت نشده است.') if not r else await u.message.reply_text(f"🎉 آخرین قرعه‌کشی\n\n🎫 {r['winner_number']}\n👤 {r['first_name'] or r['username'] or 'بدون نام'}\n🔐 {r['draw_id']}\n🕐 {r['created_at']}")
def main():
    if not settings.bot_token: raise RuntimeError('BOT_TOKEN تنظیم نشده است.')
    init_db(); app=Application.builder().token(settings.bot_token).build()
    for cmd,fn in [('start',start),('mynumber',mynumber),('vote',vote),('admin',adm),('addcandidate',addc),('startvote',startv),('endvote',endv),('results',results),('draw',draw),('status',stat),('lastdraw',last)]: app.add_handler(CommandHandler(cmd,fn))
    app.add_handler(CallbackQueryHandler(check,pattern='^check_member$')); app.add_handler(CallbackQueryHandler(vote_cb,pattern='^vote:'))
    app.run_polling()
if __name__=='__main__': main()
