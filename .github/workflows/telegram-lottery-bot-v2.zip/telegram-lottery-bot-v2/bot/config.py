import os
from dataclasses import dataclass
from dotenv import load_dotenv
load_dotenv()
@dataclass(frozen=True)
class Settings:
    bot_token: str=os.getenv('BOT_TOKEN','')
    channel_username: str=os.getenv('CHANNEL_USERNAME','@QCMaste')
    database_path: str=os.getenv('DATABASE_PATH','data/lottery.db')
    timezone: str=os.getenv('TIMEZONE','Asia/Tehran')
    @property
    def admin_ids(self):
        return {int(x.strip()) for x in os.getenv('ADMIN_IDS','').split(',') if x.strip().isdigit()}
settings=Settings()
