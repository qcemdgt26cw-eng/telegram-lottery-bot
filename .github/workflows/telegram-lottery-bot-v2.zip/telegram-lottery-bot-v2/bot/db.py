import sqlite3, uuid
from pathlib import Path
from secrets import randbelow
from datetime import datetime, timezone
from bot.config import settings

def _conn():
    Path(settings.database_path).parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(settings.database_path); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def now(): return datetime.now(timezone.utc).isoformat()
def init_db():
    with _conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,telegram_id INTEGER UNIQUE NOT NULL,username TEXT,first_name TEXT,participant_number INTEGER UNIQUE NOT NULL,registered_at TEXT NOT NULL,is_active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS candidates(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,created_at TEXT NOT NULL,is_active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS votes(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER UNIQUE NOT NULL,candidate_id INTEGER NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(candidate_id) REFERENCES candidates(id));
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS draws(id INTEGER PRIMARY KEY AUTOINCREMENT,draw_id TEXT UNIQUE NOT NULL,winner_user_id INTEGER NOT NULL,winner_number INTEGER NOT NULL,candidate_id INTEGER,algorithm_version TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(winner_user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,admin_id INTEGER NOT NULL,action TEXT NOT NULL,details TEXT,created_at TEXT NOT NULL);
        INSERT OR IGNORE INTO settings(key,value) VALUES('phase','registration');''')

def register_member(tid,username=None,first_name=None):
    with _conn() as c:
        r=c.execute('SELECT * FROM users WHERE telegram_id=?',(tid,)).fetchone()
        if r:
            c.execute('UPDATE users SET username=?,first_name=? WHERE telegram_id=?',(username,first_name,tid))
        else:
            n=c.execute('SELECT COALESCE(MAX(participant_number),0)+1 FROM users').fetchone()[0]
            c.execute('INSERT INTO users(telegram_id,username,first_name,participant_number,registered_at) VALUES(?,?,?,?,?)',(tid,username,first_name,n,now()))
        return dict(c.execute('SELECT * FROM users WHERE telegram_id=?',(tid,)).fetchone())

def get_user(tid):
    with _conn() as c:
        r=c.execute('SELECT * FROM users WHERE telegram_id=?',(tid,)).fetchone(); return dict(r) if r else None

def add_candidate(name):
    with _conn() as c: c.execute('INSERT OR IGNORE INTO candidates(name,created_at) VALUES(?,?)',(name,now()))
def candidates():
    with _conn() as c: return [dict(r) for r in c.execute('SELECT id,name FROM candidates WHERE is_active=1 ORDER BY id')]
def set_phase(p):
    with _conn() as c: c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('phase',?)",(p,))
def get_phase():
    with _conn() as c:
        r=c.execute("SELECT value FROM settings WHERE key='phase'").fetchone(); return r['value'] if r else 'registration'
def cast_vote(tid,cid):
    if get_phase()!='voting': return False,'❌ رأی‌گیری فعال نیست.'
    with _conn() as c:
        u=c.execute('SELECT id FROM users WHERE telegram_id=? AND is_active=1',(tid,)).fetchone()
        if not u: return False,'❌ ابتدا ثبت‌نام کنید.'
        if not c.execute('SELECT id FROM candidates WHERE id=? AND is_active=1',(cid,)).fetchone(): return False,'❌ نامزد موردنظر پیدا نشد.'
        try: c.execute('INSERT INTO votes(user_id,candidate_id,created_at) VALUES(?,?,?)',(u['id'],cid,now()))
        except sqlite3.IntegrityError: return False,'❌ شما قبلاً رأی داده‌اید.'
        return True,'✅ رأی شما با موفقیت ثبت شد.'
def results_db():
    with _conn() as c: return [dict(r) for r in c.execute('SELECT c.id,c.name,COUNT(v.id) vote_count FROM candidates c LEFT JOIN votes v ON c.id=v.candidate_id WHERE c.is_active=1 GROUP BY c.id,c.name ORDER BY vote_count DESC,c.id')]
def status():
    with _conn() as c:
        return {'phase':get_phase(),'members':c.execute('SELECT COUNT(*) FROM users WHERE is_active=1').fetchone()[0],'candidates':c.execute('SELECT COUNT(*) FROM candidates WHERE is_active=1').fetchone()[0],'votes':c.execute('SELECT COUNT(*) FROM votes').fetchone()[0]}
def draw_winner():
    if get_phase()!='ended': return None,'⚠️ ابتدا رأی‌گیری را پایان دهید.'
    with _conn() as c:
        old=c.execute('SELECT * FROM draws ORDER BY id DESC LIMIT 1').fetchone()
        if old: return dict(old),'ℹ️ برای این دوره قبلاً قرعه‌کشی ثبت شده است.'
        rows=c.execute('SELECT u.id,u.participant_number,u.first_name,u.username,v.candidate_id FROM users u JOIN votes v ON u.id=v.user_id WHERE u.is_active=1').fetchall()
        if not rows: return None,'❌ شرکت‌کننده دارای رأی وجود ندارد.'
        w=rows[randbelow(len(rows))]; did=str(uuid.uuid4())
        c.execute('INSERT INTO draws(draw_id,winner_user_id,winner_number,candidate_id,algorithm_version,created_at) VALUES(?,?,?,?,?,?)',(did,w['id'],w['participant_number'],w['candidate_id'],'secure-random-v2',now()))
        return {'draw_id':did,'winner_number':w['participant_number'],'name':w['first_name'] or w['username'] or 'بدون نام'},'🎉 قرعه‌کشی با موفقیت انجام شد.'
def log_admin(a,action,details=''):
    with _conn() as c: c.execute('INSERT INTO audit_log(admin_id,action,details,created_at) VALUES(?,?,?,?)',(a,action,details,now()))
def last_draw():
    with _conn() as c:
        r=c.execute('SELECT d.*,u.first_name,u.username FROM draws d JOIN users u ON u.id=d.winner_user_id ORDER BY d.id DESC LIMIT 1').fetchone(); return dict(r) if r else None
