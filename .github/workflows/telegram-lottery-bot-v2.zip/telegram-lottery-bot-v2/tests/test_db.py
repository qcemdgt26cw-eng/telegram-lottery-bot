from pathlib import Path
def test_files():
    assert Path('bot/main.py').exists()
    assert Path('bot/db.py').exists()
    assert Path('bot/config.py').exists()
