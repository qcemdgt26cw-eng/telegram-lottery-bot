# Telegram Lottery Bot V2

ربات تلگرامی ثبت‌نام، رأی‌گیری و قرعه‌کشی با SQLite.

## امکانات
- بررسی عضویت کانال و صدور شماره یکتای شرکت‌کننده
- یک رأی برای هر کاربر
- مدیریت نامزدها و مراحل رأی‌گیری
- قرعه‌کشی با `secrets.randbelow`
- ثبت دائمی نتیجه و جلوگیری از قرعه‌کشی مجدد
- Audit Log عملیات ادمین
- GitHub Actions برای تست

## اجرا
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m bot.main
```

توکن واقعی را هرگز در GitHub قرار ندهید.
